from flask import Flask, render_template, request, jsonify, url_for
from g4f.client import Client
from googletrans import Translator, LANGUAGES
import os
import Levenshtein
import sqlite3
import keyboard
import fitz
from g4f.client import Client
import pyttsx3
import speech_recognition as sr
from g4f.client import Client
app = Flask(__name__)
from eded import process_audio_with_gemini
conn = sqlite3.connect('quiz.db', check_same_thread=False)
cursor = conn.cursor()
red={}
client = Client()
translator = Translator()
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
engine = pyttsx3.init()
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id) 
def split_question_and_answer(text):
    global red
    text = text.strip()
    parts = text.split("Answer:")
    question = parts[0].replace("Question:", "").strip()
    print(question)
    answer = parts[1].strip()
    questions12=question.split("\n")
    print(questions12)
    question=questions12[0]
    red={"option1":questions12[1],"option2":questions12[2],"option3":questions12[3],"option4":questions12[4]}
    print(red)
    answer = parts[1].strip()
    print(answer)
    return question, answer,red
import speech_recognition as sr
from pydub import AudioSegment
@app.route('/upload-audio', methods=['POST'])
def upload_audio():
    if 'audio_file' not in request.files:
        return "No file part", 400

    file = request.files['audio_file']
    

    save_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(save_path)
    print(f"Audio saved to {save_path}")
    a=process_audio_with_gemini(save_path)
    print(a)
    try:
        text = a
        return jsonify({"transcription": text})
    except sr.UnknownValueError:
        return jsonify({"error": "Could not understand the audio"}), 400
    except sr.RequestError:
        return jsonify({"error": "Could not request results from Google Speech Recognition service"}), 500

def speak(text):
    """
    Convert text to speech.
    """
    engine.say(text)
    engine.runAndWait()

def get_answer_from_input(answer):
    """
    Capture the answer from the user's input.
    """
    return answer.strip().lower()

def fetch_quiz_question(topic):
    """
    Fetch a quiz question for a given topic.
    """
    global red
    prompt = (
        f"Generate a simple one quiz question related to the topic '{topic}'. with the options of 4 options needed"
        "Provide the response in the format: 'Question: [question text] and with the options of 4 options needed and option in next to next directly give the option without option title. give solution like this Answer: [answer]' with full word  for particular option."
        "dont ask same questions important"
    )
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        )

        content = response.choices[0].message.content.strip()
        print(content)
        if "Question:" not in content or "Answer:" not in content:
            raise ValueError("The response format is incorrect. Ensure it contains both 'Question:' and 'Answer:'.")

        question, answer,red = split_question_and_answer(content)

        return question, answer,red

    except Exception as e:
        print(f"Error fetching quiz question: {e}")
        return None, None
engine = pyttsx3.init()
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)  
global stop_flag
keyboard.wait('ctrl+y')  
print("Stopping speech...")
engine.stop() 
stop_flag = True
from syllabipy.sonoripy import SonoriPy  
def syllabify_and_pronounce(text):
    syllabified_words = []
    words = text.split()
    for word in words:
        clean_word = word.strip(".,:;!?")  
        syllable_parts = []
        if len(clean_word) <= 2:
            syllable_parts.append(clean_word)  
        else:
            syllabified = SonoriPy(clean_word)
            syllable_parts.extend(syllabified)  
        syllabified_words.append(" ".join(syllable_parts))  

    return syllabified_words
def summarize_content(content):
    """
    Generate a simplified summary of the content using GPT.
    """
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": f"Summarize the following content simply: {content}"}],
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error generating summary: {str(e)}"

def summarize_content123(content):
    """
    Generate a simplified summary of the content using GPT.
    """
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": f"The user needs help with either solving mental health issues or getting career guidance. Please provide thoughtful, supportive, and practical advice in points based on the user’s message :  {content}"}],
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error generating summary: {str(e)}"

def split_question_and_answer(text):
    """
    Split the given text into a question and an answer.
    """
    global red
    text = text.strip()
    parts = text.split("Answer:")
    question = parts[0].replace("Question:", "").strip()
    print(question)
    questions12=question.split("\n")
    print(questions12)
    question=questions12[0]
    red={"option1":questions12[1],"option2":questions12[2],"option3":questions12[3],"option4":questions12[4]}
    print(red)
    answer = parts[1].strip()
    print(answer)
    return question, answer,red
@app.route('/mute', methods=['POST'])
def mute():
    return jsonify({"status": "muted"})
@app.route("/")
def home():
    """
    Render the home page.
    """
    return render_template("home.html")
@app.route("/summary_chatbot12", methods=["GET", "POST"])
def summary_chatbotd():
    """
    Summary Chatbot Page - Accepts text and returns summarized content.
    """
    if request.method == "POST":
        user_text = request.json.get("text", "")
        summary = summarize_content123(user_text)
        return jsonify({"summary": summary})
    return render_template("code.html")
@app.route("/summary_chatbot", methods=["GET", "POST"])
def summary_chatbot():
    """
    Summary Chatbot Page - Accepts text and returns summarized content.
    """
    if request.method == "POST":
        user_text = request.json.get("text", "")
        summary = summarize_content(user_text)
        return jsonify({"summary": summary})
    return render_template("summary_chatbot.html")
@app.route('/send_message', methods=['POST'])
def send_message():
    """
    Processes user messages and returns summarized or transformed content.
    """
    message = request.json.get('message', "No input provided.")

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": f"Reduce the code size and simplify it: {message}"}
            ],
        )
        reduced_code = response.choices[0].message.content.strip()
        return jsonify({'rows': reduced_code})
    except Exception as e:
        return jsonify({'error': str(e)})
iopuy=0    
@app.route("/code_chatbot")
def code_chatbot():

    return render_template("code_chatbot.html")

@app.route("/code_chat")
def code_chatbot123():

    return render_template("code.html")
@app.route("/Whiteboard")
def Whiteboard():

    return render_template("Whiteboard.html")

@app.route('/pronunce')
def pronunce():
    return render_template('pronunce.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"})
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"})

    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        tyu=[]
        pdf_document = fitz.open(file_path)
        syllabified_text = []
        for page_number in range(len(pdf_document)):
            page = pdf_document[page_number]
            extracted_text = page.get_text()
            print(extracted_text)
            tyu.append(str(extracted_text))
            words = extracted_text.split()
            syllables = []

            for word in words:
                clean_word = word.strip(".,:;!?")
                if len(clean_word) > 2:
                    syllabified = SonoriPy(clean_word)
                    syllables.append("-".join(syllabified))
                    syllables.append("denotes"+" "+str(clean_word))
                else:
                    syllables.append(clean_word)

            syllabified_text.extend(syllables)
        print(tyu)
        return jsonify({"syllabified_text": syllabified_text})
@app.route('/quiz')
def quiz():
    return render_template('quiz.html')

@app.route('/get_question', methods=['POST'])
def get_question():
    """
    Fetch a quiz question based on the topic.
    """
    global red
    print(red)
    topic = request.json['topic']
    question, answer, red = fetch_quiz_question(topic)
    print(red)
    if question and answer:
        re=question+"\n"+red['option1']+"\n"+ red['option2']+"\n"+red['option3']+"\n"+red['option4']
        print(re)
        print(answer)
        return jsonify({'question': question, 'answer': answer,'red':red})
    else:
        return jsonify({'error': 'Unable to fetch question'})
def init_db():
    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    
    cursor.execute('''
     CREATE TABLE new_quiz_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    question TEXT,
    answer TEXT,
    correct_answer TEXT,
    is_correct INTEGER,
    FOREIGN KEY(user_id) REFERENCES users(id)
);
    ''')
    conn.commit()
    conn.close()
@app.route('/submit_answer', methods=['POST'])
def submit_answer():
    data = request.json
    user_id = data.get('user_id')  # Unique ID for tracking
    question = data.get('question')
    answer = data.get('answer')
    
    correct_answer = data.get('correct_answer')
    answer=answer[3:len(answer)]
    print(answer,correct_answer,sep='\n')
    if answer == correct_answer or correct_answer in answer or answer in correct_answer:
        global iopuy
        iopuy=iopuy+1
        is_correct = 1 
    else:
        is_correct = 0
    
    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO quiz_results (user_id, question, answer, correct_answer, is_correct) VALUES (?, ?, ?, ?, ?)',
                   (user_id, question, answer, correct_answer, is_correct))
    conn.commit()
    cursor.execute('SELECT SUM(is_correct) FROM quiz_results WHERE user_id = ?', (user_id,))
    total_score = cursor.fetchone()[0] or 0  
    conn.close()

    return jsonify({
        "response": "✅ Correct!" if is_correct else "❌ Incorrect!",
        "score": iopuy,
        "correct_answer": correct_answer if not is_correct else None
    })
engine = pyttsx3.init()
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)  
pages = {
    "chatbot": "summary_chatbot",
    "quiz": "quiz",
    "features": "#features",
    "contact": "#contact"
}
def speak(text):
    """
    Convert text to speech.
    """
    engine.say(text)
    engine.runAndWait()
@app.route('/navigate', methods=['POST'])
def navigate():
    data = request.get_json()
    text = data['text'].lower()
    closest_match = None
    min_distance = float('inf')

    for keyword, page in pages.items():
        distance = Levenshtein.distance(text, keyword)
        if distance < min_distance:
            min_distance = distance
            closest_match = page

    if closest_match:
        if closest_match.startswith('#'):
            page_url = closest_match
        else:
            page_url = url_for(closest_match)

        return jsonify({'success': True, 'page_url': page_url})
    else:
        return jsonify({'success': False, 'message': 'Page not found'})

@app.route('/voice_control')
def voice_control():
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()
    speak("Say the page you want to navigate to or a message to type. Say 'stop' to end.")

    while True:
        with microphone as source:
            print("Listening for command...")
            recognizer.adjust_for_ambient_noise(source)
            audio = recognizer.listen(source)

        try:
            command = recognizer.recognize_google(audio).lower()
            print(f"Recognized command: {command}")

            if "stop" in command:
                speak("Stopping voice control.")
                break
            if "go to" in command:
                page_command = command.split("go to")[1].strip()
                data = {'text': page_command}
                response = navigate() 
                if response.json.get('success'):
                    speak(f"Navigating to {response.json.get('page_url')}")
                else:
                    speak("I couldn't understand the command. Try again.")
            elif "type" in command:
                message = command.split("type")[1].strip()
                speak(f"Typing message: {message}")
                speak(f"Message '{message}' sent!")
        except sr.UnknownValueError:
            speak("Sorry, I didn't catch that. Please say it again.")
        except sr.RequestError as e:
            speak(f"Error with speech service: {e}")

    return jsonify({"success": True, "message": "Voice control ended."})
if  __name__=="__main__":
   app.run(debug=False,port=5008, threaded=True)
