import pyaudio
import wave
from google import genai
from pydub import AudioSegment

# Initialize the GenAI Client with your API Key
client = genai.Client(api_key="AIzaSyAF-Pq4AZdOicHKsoJfuP9ClFmUGLnCVE4")
import pyaudio
import wave
from google import genai
from pydub import AudioSegment

# Initialize the GenAI Client with 

# Function to record audio and save it as a .wav file
def record_audio(file_path="recorded_audio.wav", duration=40):
    # Initialize audio stream
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16,
                    channels=1,
                    rate=16000,
                    input=True,
                    frames_per_buffer=1024)
    print(f"Recording audio for {duration} seconds...")

    frames = []
    for _ in range(0, int(16000 / 1024 * duration)):
        data = stream.read(1024)
        frames.append(data)

    # Stop recording
    print("Recording finished.")
    stream.stop_stream()
    stream.close()
    p.terminate()

    # Save the recorded audio as a .wav file
    with wave.open(file_path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(p.get_sample_size(pyaudio.paInt16))
        wf.setframerate(16000)
        wf.writeframes(b''.join(frames))

# Convert the .wav file to .mp3 format (required by Google API)
def convert_wav_to_mp3(wav_file, mp3_file):
    audio = AudioSegment.from_wav(wav_file)
    audio.export(mp3_file, format="mp3")
    print(f"Audio converted to {mp3_file}")

# Function to upload audio to Gemini and get the response
def process_audio_with_gemini(mp3_file):
    # Open the .mp3 file
    with open(mp3_file, 'rb') as file:
        # Upload the audio file
        import pyaudio
        import wave
        from google import genai
        from pydub import AudioSegment
        import google.generativeai as genai

        # Replace with your actual Gemini API key
        GEMINI_API_KEY = "AIzaSyAF-Pq4AZdOicHKsoJfuP9ClFmUGLnCVE4"
        genai.configure(api_key=GEMINI_API_KEY)
        model = genai.GenerativeModel('gemini-pro')
        from google import genai

        client = genai.Client(api_key="AIzaSyAF-Pq4AZdOicHKsoJfuP9ClFmUGLnCVE4")

        myfile = client.files.upload(path=r"C:\Users\deepak\Desktop\nittrichy\recorded_audio.mp3")

        response = client.models.generate_content(
            model="gemini-2.0-flash", contents=["translate into english only no unwanted words", myfile]
        )

        print(response.text)

    # Print the generated response text
    print("Generated Content from Gemini:")
    print(response.text)
    return response.text

# Main function
def main():
    # Step 1: Record audio and save it as a .wav file
    record_audio(file_path="recorded_audio.wav", duration=10)

    # Step 2: Convert the recorded .wav file to .mp3 format
    convert_wav_to_mp3("recorded_audio.wav", "recorded_audio.mp3")

    # Step 3: Send the .mp3 file to Gemini and get the response
    a=process_audio_with_gemini("recorded_audio.mp3")
    print(a)


