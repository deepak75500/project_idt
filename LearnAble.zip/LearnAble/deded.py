import sqlite3

# Connect to your SQLite database
conn = sqlite3.connect('quiz.db')
cursor = conn.cursor()

# Define the user ID you're looking for
user_id = "1"
user_id12="deepak2"
# Query the database to get the user's marks
cursor.execute("SELECT count(*) FROM quiz_results WHERE  is_correct = ? and user_id = ?", (user_id,user_id12))
result = cursor.fetchall()

for i in result:
    print(i)
# Close the connection
conn.close()
